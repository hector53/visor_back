#datos localhost
datos = {
    "host":"localhost",
    "database":"rofex",
    "userDb" : "root",
    "userPass":"",
    "secret_key_login": '65as4d56as4das651ads86'
}

#datos Host para db
host=datos["host"]
database=datos["database"]
userDb = datos["userDb"]
userPass=datos["userPass"]
length_of_string = 8
